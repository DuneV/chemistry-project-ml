"""Genetic Algorithm over SELFIES - a working generative demo."""
import numpy as np
import selfies as sf
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors
from rdkit import DataStructs as DS
import random
random.seed(42); np.random.seed(42)

# Strong binders as seeds
strong = ["OC(=O)c1cc(O)c(O)c(O)c1","OC(=O)C(=O)CS","OC(=O)C(S)C(S)C(=O)O",
          "OC(=O)CC(O)(C(=O)O)CC(=O)O","OC(=O)CS","OC(=O)c1ccccn1","NC(CC(N)=O)C(=O)O"]
strong_fps = [AllChem.GetMorganFingerprintAsBitVect(Chem.MolFromSmiles(s),2,1024) for s in strong]
all_train_smiles = set(Chem.MolToSmiles(Chem.MolFromSmiles(s)) for s in strong)

def score(smi):
    m = Chem.MolFromSmiles(smi)
    if m is None: return -1
    mw = Descriptors.MolWt(m)
    if not (60 <= mw <= 300): return -1
    fp = AllChem.GetMorganFingerprintAsBitVect(m,2,1024)
    sim = max(DS.TanimotoSimilarity(fp,sf_) for sf_ in strong_fps)
    n_cooh = len(m.GetSubstructMatches(Chem.MolFromSmarts("C(=O)[OH]")))
    n_sh = len(m.GetSubstructMatches(Chem.MolFromSmarts("[SX2H]")))
    dsc = min((n_cooh+n_sh)/3.0,1.0)
    return 0.6*sim + 0.4*dsc

# SELFIES alphabet from seeds
seed_selfies = [sf.encoder(s) for s in strong]
alphabet = set()
for s in seed_selfies:
    for tok in list(sf.split_selfies(s)):
        alphabet.add(tok)
alphabet = list(alphabet)

def mutate(selfies_str):
    toks = list(sf.split_selfies(selfies_str))
    if not toks: return selfies_str
    op = random.choice(["sub","ins","del"])
    i = random.randint(0,len(toks)-1)
    if op=="sub": toks[i] = random.choice(alphabet)
    elif op=="ins": toks.insert(i, random.choice(alphabet))
    elif op=="del" and len(toks)>2: toks.pop(i)
    return "".join(toks)

def crossover(a,b):
    ta,tb = list(sf.split_selfies(a)), list(sf.split_selfies(b))
    if len(ta)<2 or len(tb)<2: return a
    ca,cb = random.randint(1,len(ta)-1), random.randint(1,len(tb)-1)
    return "".join(ta[:ca]+tb[cb:])

# GA loop
pop = list(seed_selfies)
for gen in range(30):
    # expand population
    children = []
    for _ in range(60):
        if random.random()<0.5:
            child = mutate(random.choice(pop))
        else:
            child = crossover(random.choice(pop), random.choice(pop))
        children.append(child)
    pop = pop + children
    # score & select
    scored = []
    seen = set()
    for s in pop:
        try:
            smi = sf.decoder(s)
            m = Chem.MolFromSmiles(smi)
            if m is None: continue
            canon = Chem.MolToSmiles(m)
            if canon in seen: continue
            seen.add(canon)
            scored.append((s, canon, score(smi)))
        except: continue
    scored.sort(key=lambda x:x[2], reverse=True)
    pop = [s for s,c,sc in scored[:30]]  # keep top 30

# Final novel candidates (not in training)
final = []
for s,c,sc in scored:
    if c not in all_train_smiles and sc > 0.4:
        final.append((c, sc))
    if len(final)>=15: break

print("GENERATED NOVEL CANDIDATES (not in training set):")
print("="*55)
print(f"{'SMILES':<38}{'Score':>7}")
print("-"*55)
for smi, sc in final:
    print(f"{smi:<38}{sc:>7.3f}")
print(f"\nGenerated {len(final)} novel valid candidates via SELFIES-GA")
print("These would be the molecules to validate with DFT.")
