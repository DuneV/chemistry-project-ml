"""
MXene Ligand Generative Design Pipeline
========================================
A generative modeling approach for discovering new MXene-functionalizing ligands.

Strategy (works with small datasets by leveraging pre-trained chemical knowledge):
  1. Define the "target profile" from the strongest-binding training ligands
     (multiple donor atoms / chelating groups, specific donor chemistry).
  2. Generate candidate molecules with a generative model over SELFIES strings
     (SELFIES guarantees 100% chemically valid molecules, unlike raw SMILES).
  3. Score generated candidates by similarity to strong binders + drug-likeness
     + presence of donor groups (a surrogate acquisition objective).
  4. Output ranked novel candidates for DFT validation.

This is the "generative + simulation validation" workflow the Nature SR
Collection 'Generative Modeling for Chemistry Discovery' asks for.

Author: base pipeline for Daniel to develop (the generative ML component).
"""
import numpy as np
import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, DataStructs
from rdkit import DataStructs as DS

# ----------------------------------------------------------------------
# 1. TRAINING LIGANDS (18) with their E_ads - defines what "good" looks like
# ----------------------------------------------------------------------
train = [
    ("gallic_acid","OC(=O)c1cc(O)c(O)c(O)c1",-1.951),
    ("mercaptopyruvic_acid","OC(=O)C(=O)CS",-1.651),
    ("23-dimercaptosuccinic","OC(=O)C(S)C(S)C(=O)O",-1.608),
    ("citric_acid","OC(=O)CC(O)(C(=O)O)CC(=O)O",-0.886),
    ("thioglycolic_acid","OC(=O)CS",-0.795),
    ("picolinic_acid","OC(=O)c1ccccn1",-0.646),
    ("asparagine","NC(CC(N)=O)C(=O)O",-0.513),
    ("dopamine","NCCc1ccc(O)c(O)c1",-0.351),
    ("penicillamine","CC(C)(S)C(N)C(=O)O",-0.244),
    ("ethylenediamine","NCCN",-0.215),
    ("cysteine","NC(CS)C(=O)O",-0.208),
    ("protocatechuic_acid","OC(=O)c1ccc(O)c(O)c1",-0.091),
    ("glycolic_acid","OCC(=O)O",0.003),
    ("ethanolamine","NCCO",0.018),
    ("mucic_acid","OC(=O)C(O)C(O)C(O)C(O)C(=O)O",0.091),
    ("citrulline","NC(CCCNC(N)=O)C(=O)O",0.129),
    ("2-mercaptopropane","CC(C)S",0.285),
    ("benzylamine","NCc1ccccc1",0.337),
]

# Strong binders (E_ads < -0.5 eV) define the target chemical space
strong = [smi for name,smi,ea in train if ea < -0.5]
print(f"Strong-binder reference set ({len(strong)} ligands, E_ads < -0.5 eV):")
for name,smi,ea in train:
    if ea < -0.5: print(f"  {name}: {ea} eV")

# Morgan fingerprints of strong binders
strong_fps = [AllChem.GetMorganFingerprintAsBitVect(Chem.MolFromSmiles(s),2,1024) for s in strong]

def strong_similarity(smi):
    m = Chem.MolFromSmiles(smi)
    if m is None: return 0.0
    fp = AllChem.GetMorganFingerprintAsBitVect(m,2,1024)
    sims = [DS.TanimotoSimilarity(fp,sf) for sf in strong_fps]
    return max(sims)  # closeness to the nearest strong binder

# ----------------------------------------------------------------------
# 2. SCORING FUNCTION (surrogate objective for generation)
# ----------------------------------------------------------------------
def donor_score(m):
    # reward chelating potential: multiple donor atoms / carboxyl / thiol / catechol
    n_cooh = len(m.GetSubstructMatches(Chem.MolFromSmarts("C(=O)[OH]")))
    n_sh   = len(m.GetSubstructMatches(Chem.MolFromSmarts("[SX2H]")))
    n_nh2  = len(m.GetSubstructMatches(Chem.MolFromSmarts("[NX3;H2]")))
    n_cat  = len(m.GetSubstructMatches(Chem.MolFromSmarts("c1cc(O)c(O)cc1")))  # catechol
    return n_cooh + n_sh + 0.5*n_nh2 + 2*n_cat

def score_candidate(smi):
    m = Chem.MolFromSmiles(smi)
    if m is None: return None
    mw = Descriptors.MolWt(m)
    if not (60 <= mw <= 300): return None
    sim = strong_similarity(smi)
    dsc = donor_score(m)
    # combined surrogate score
    return 0.6*sim + 0.4*min(dsc/3.0, 1.0)

print("\n" + "="*60)
print("This is the SCORING backbone. The GENERATIVE part (Daniel):")
print("="*60)
print("""
Daniel implements a generative model that PROPOSES new molecules,
then this scoring ranks them. Recommended generative approaches
(in order of feasibility with a small dataset):

  A. SELFIES-VAE with transfer learning:
     - Pre-train a VAE on a large set (e.g. ZINC250k or ChEMBL) so it
       learns valid chemistry, then fine-tune / bias sampling toward
       the strong-binder region using the 18 labeled ligands.
     - Libraries: selfies, torch. Reference VAE: github MolVAE / JT-VAE.

  B. Genetic algorithm over SELFIES (simplest, robust, no big pretraining):
     - Start from the strong binders, apply mutations/crossover on SELFIES
       tokens, keep high-scoring offspring. This is a valid 'generative'
       method and works with tiny data. Library: selfies + custom GA.
     - This is the RECOMMENDED starting point given the timeline.

  C. Reinforcement learning (REINVENT-style):
     - Agent generates SMILES, reward = score_candidate above.
     - More complex; optional if time allows.

Deliverable: ~20-50 NOVEL, valid, high-scoring candidate ligands
that are NOT in the training set, for Julie to validate with DFT.
""")

# Quick demo of the GA idea using the scoring on the library candidates
print("="*60)
print("DEMO: scoring the existing 130-candidate library as a stand-in")
print("(shows which known candidates the objective favors - the real")
print(" generative model would propose NEW ones beyond this list)")
print("="*60)
